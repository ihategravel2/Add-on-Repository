// READ ME //

Hi, this is Rahee from Blocky Magpie Bangladesh.
I would like to say thanks for downloading my resource pack for Minecraft Bedrock edition

Please don't redistribute this pack with/without any modifications.
Feel free to modify this pack for OWN PERSONAL use.

Name: EasyEggs
Version: 1.0.0
Compatible game version: 1.16+
:D Happy editing